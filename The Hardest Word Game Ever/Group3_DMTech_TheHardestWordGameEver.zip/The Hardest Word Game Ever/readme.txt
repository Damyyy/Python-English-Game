Ensure that you have both Pygame and RandomWord installed into Python



Instructions
1. Go to Start and open Command Prompt (CMD)
2. Type pip to check if you have pip works
3. If it works, type "pip install pygame" into the Command Prompt (CMD)
4. It would install pygame into Python
5. Now do it the same way but this time it would be RandomWord
6. Type "pip install RandomWord" exactly like this
7. RandomWord would be installed into Python
8. After all of this is done, double click on main and enjoy the game
9. Incase you have errors while installing both Pygame and RandomWord, please click the link and watch the video.


Click on this link to see how to install both Pygame
Link: https://www.youtube.com/watch?v=AdUZArA-kZw&t=337s